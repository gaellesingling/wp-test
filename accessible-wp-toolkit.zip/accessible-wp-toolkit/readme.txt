=== Accessible WP Toolkit ===
Contributors: your-name
Tags: accessibility, a11y, wcag, aria
Requires at least: 6.0
Tested up to: 6.x
Requires PHP: 7.4
Stable tag: 0.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Skeleton d’outils d’accessibilité pour WordPress (placeholders).

== Description ==
Page d’admin dédiée avec icône `dashicons-universal-access-alt`. Placeholders pour:
- Vérif. contrastes couleurs (WCAG)
- Audit navigation clavier
- Landmarks ARIA
- Médias: sous-titres/transcriptions

== Installation ==
1. Copier le dossier `accessible-wp-toolkit` dans `wp-content/plugins/`.
2. Activer le plugin depuis l’admin WordPress.

== Changelog ==
= 0.1.0 =
* Version initiale (squelette)
