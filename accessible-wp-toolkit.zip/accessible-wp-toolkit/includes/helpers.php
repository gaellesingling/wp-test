<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function awpt_capability() : string {
    return 'manage_options';
}
