(function($){
  $(function(){
    // Placeholder: scripts d’admin à venir
    // console.log('AWPT admin loaded');
  });
})(jQuery);
