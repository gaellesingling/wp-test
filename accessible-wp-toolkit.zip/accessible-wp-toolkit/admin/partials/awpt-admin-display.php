<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="wrap awpt">
    <h1><?php echo esc_html__( 'Accessible WP Toolkit', 'accessible-wp-toolkit' ); ?></h1>
    <p class="description">
        <?php echo esc_html__( 'Placeholders des futurs outils d’accessibilité.', 'accessible-wp-toolkit' ); ?>
    </p>

    <div class="awpt-grid">
        <div class="awpt-card">
            <h2><?php echo esc_html__( 'Contraste des couleurs', 'accessible-wp-toolkit' ); ?></h2>
            <p><?php echo esc_html__( 'Vérifiez le contraste selon WCAG (à venir).', 'accessible-wp-toolkit' ); ?></p>
            <form method="post">
                <?php wp_nonce_field( 'awpt_contrast', 'awpt_nonce' ); ?>
                <input type="text" name="bg" placeholder="#FFFFFF" />
                <input type="text" name="fg" placeholder="#000000" />
                <button class="button button-primary" disabled><?php echo esc_html__( 'Calculer (bientôt)', 'accessible-wp-toolkit' ); ?></button>
            </form>
        </div>

        <div class="awpt-card">
            <h2><?php echo esc_html__( 'Audit navigation clavier', 'accessible-wp-toolkit' ); ?></h2>
            <p><?php echo esc_html__( 'Détectez les pièges de focus, etc. (à venir).', 'accessible-wp-toolkit' ); ?></p>
            <button class="button" disabled><?php echo esc_html__( 'Analyser (bientôt)', 'accessible-wp-toolkit' ); ?></button>
        </div>

        <div class="awpt-card">
            <h2><?php echo esc_html__( 'Repères ARIA', 'accessible-wp-toolkit' ); ?></h2>
            <p><?php echo esc_html__( 'Insertion/validation des landmarks (à venir).', 'accessible-wp-toolkit' ); ?></p>
        </div>

        <div class="awpt-card">
            <h2><?php echo esc_html__( 'Sous-titres & médias', 'accessible-wp-toolkit' ); ?></h2>
            <p><?php echo esc_html__( 'Vérification des sous-titres/transcriptions (à venir).', 'accessible-wp-toolkit' ); ?></p>
        </div>
    </div>
</div>
